console.log("%cHey there friends at AMBR Detroit!", "color: grey; font-size: x-large");
console.log("");
console.log("%cI had a lot of fun with your scavenger hunt and this design project.", "color: grey; font-size: large");
console.log("%cHopefully you like what you see and we can talk some more ツ", "color: grey; font-size: large");
console.log("");
console.log("%cI am extremely passionate about building awesome web things for people to interact with. I think the web is a valuable medium and should be crafted with precision and care. I'm currently looking for a great team to call my family and an exciting company to call home.", "color: grey; font-size: medium"); 
console.log("");
console.log("%cYou can creep on more of my work from my personal site (arnaud.cr), my portfolio site (miniml.co), or my github (@areknow). I also mess around with my camera (@areknowsee) when I’m not busy filling brackets.", "color: grey; font-size: medium");
console.log("");
